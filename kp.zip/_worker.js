import { connect } from 'cloudflare:sockets';

// --- Configuration ---
let subPath = 'link';
let proxyIP = 'jp.yutian.nyc.mn';
let password = '5dc15e15-f285-4a9d-959b-0e4fbdd77b63';
let SSpath = '';

let cfip = [
    'mfa.gov.ua#SG', 'saas.sin.fan#JP', 'store.ubi.com#SG','cf.130519.xyz#KR','cf.008500.xyz#HK',
    'cf.090227.xyz#SG', 'cf.877774.xyz#HK','cdns.doon.eu.org#JP','sub.danfeng.eu.org#TW','cf.zhetengsha.eu.org#HK'
];

// =============================================================
// Cross-Account R2 Configuration (S3 Compatible API)
// wrangler.toml (သို့) Worker Settings > Environment Variables မှာ ထည့်ပါ:
//   R2_ACCESS_KEY_ID      = "your-r2-api-token-access-key-id"
//   R2_SECRET_ACCESS_KEY  = "your-r2-api-token-secret-access-key"
//   R2_BUCKET_NAME        = "your-bucket-name"
//   R2_ACCOUNT_ID         = "target-cloudflare-account-id"  (R2 bucket ရှိတဲ့ account)
//
// R2 bucket ပိုင်ရှင် account ကနေ:
//   R2 > Manage R2 API Tokens > Create API Token
//   Permission: "Object Read only" (သို့) "Object Read & Write"
//   Specify bucket: သက်ဆိုင်ရာ bucket ကိုရွေးပါ
// =============================================================

// --- Utility Functions ---
function closeSocketQuietly(socket) {
    try {
        if (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CLOSING) {
            socket.close();
        }
    } catch (error) {}
}

function base64ToArray(b64Str) {
    if (!b64Str) return { error: null };
    try {
        const binaryString = atob(b64Str.replace(/-/g, '+').replace(/_/g, '/'));
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return { earlyData: bytes.buffer, error: null };
    } catch (error) {
        return { error };
    }
}

function parsePryAddress(serverStr) {
    if (!serverStr) return null;
    serverStr = serverStr.trim();
    if (serverStr.startsWith('socks://') || serverStr.startsWith('socks5://')) {
        const urlStr = serverStr.replace(/^socks:\/\//, 'socks5://');
        try {
            const url = new URL(urlStr);
            return {
                type: 'socks5',
                host: url.hostname,
                port: parseInt(url.port) || 1080,
                username: url.username ? decodeURIComponent(url.username) : '',
                password: url.password ? decodeURIComponent(url.password) : ''
            };
        } catch (e) {
            return null;
        }
    }
    if (serverStr.startsWith('http://') || serverStr.startsWith('https://')) {
        try {
            const url = new URL(serverStr);
            return {
                type: 'http',
                host: url.hostname,
                port: parseInt(url.port) || (serverStr.startsWith('https://') ? 443 : 80),
                username: url.username ? decodeURIComponent(url.username) : '',
                password: url.password ? decodeURIComponent(url.password) : ''
            };
        } catch (e) {
            return null;
        }
    }
    const lastColonIndex = serverStr.lastIndexOf(':');
    if (lastColonIndex > 0) {
        const host = serverStr.substring(0, lastColonIndex);
        const portStr = serverStr.substring(lastColonIndex + 1);
        const port = parseInt(portStr, 10);
        if (!isNaN(port) && port > 0 && port <= 65535) {
            return { type: 'direct', host, port };
        }
    }
    return { type: 'direct', host: serverStr, port: 443 };
}

// --- MIME Type Helper ---
function getVideoMimeType(filename) {
    const ext = filename.split('.').pop().toLowerCase();
    const mimeTypes = {
        'mp4': 'video/mp4',
        'webm': 'video/webm',
        'mkv': 'video/x-matroska',
        'mov': 'video/quicktime',
        'avi': 'video/x-msvideo',
        'flv': 'video/x-flv',
        'm4v': 'video/x-m4v',
        'ts': 'video/mp2t',
        'm3u8': 'application/vnd.apple.mpegurl',
        'mpg': 'video/mpeg',
        'mpeg': 'video/mpeg',
        'ogv': 'video/ogg',
        '3gp': 'video/3gpp',
    };
    return mimeTypes[ext] || null;
}

// =============================================================
// AWS Signature V4 for R2 S3-Compatible API
// =============================================================

async function hmacSHA256(key, message) {
    const cryptoKey = await crypto.subtle.importKey(
        'raw',
        typeof key === 'string' ? new TextEncoder().encode(key) : key,
        { name: 'HMAC', hash: 'SHA-256' },
        false,
        ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', cryptoKey, new TextEncoder().encode(message));
    return new Uint8Array(sig);
}

async function sha256Hex(data) {
    const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
    return [...new Uint8Array(hashBuffer)].map(b => b.toString(16).padStart(2, '0')).join('');
}

function getAmzDateStrings() {
    const now = new Date();
    const amzDate = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const dateStamp = amzDate.substring(0, 8);
    return { amzDate, dateStamp };
}

async function signR2Request(method, objectKey, accountId, bucketName, accessKeyId, secretAccessKey, rangeHeader) {
    const region = 'auto';
    const service = 's3';
    const host = `${bucketName}.${accountId}.r2.cloudflarestorage.com`;
    const { amzDate, dateStamp } = getAmzDateStrings();

    const encodedKey = objectKey.split('/').map(part => encodeURIComponent(part)).join('/');
    const canonicalUri = '/' + encodedKey;
    const canonicalQuerystring = '';

    const payloadHash = await sha256Hex('');

    let signedHeadersList = ['host', 'x-amz-content-sha256', 'x-amz-date'];
    let canonicalHeaders = `host:${host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${amzDate}\n`;

    const extraHeaders = {};

    if (rangeHeader) {
        signedHeadersList.push('range');
        signedHeadersList.sort();
        canonicalHeaders = '';
        const headersMap = {
            'host': host,
            'range': rangeHeader,
            'x-amz-content-sha256': payloadHash,
            'x-amz-date': amzDate,
        };
        for (const h of signedHeadersList) {
            canonicalHeaders += `${h}:${headersMap[h]}\n`;
        }
        extraHeaders['Range'] = rangeHeader;
    }

    const signedHeaders = signedHeadersList.join(';');

    const canonicalRequest = [
        method,
        canonicalUri,
        canonicalQuerystring,
        canonicalHeaders,
        signedHeaders,
        payloadHash,
    ].join('\n');

    const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
    const stringToSign = [
        'AWS4-HMAC-SHA256',
        amzDate,
        credentialScope,
        await sha256Hex(canonicalRequest),
    ].join('\n');

    const kDate = await hmacSHA256('AWS4' + secretAccessKey, dateStamp);
    const kRegion = await hmacSHA256(kDate, region);
    const kService = await hmacSHA256(kRegion, service);
    const kSigning = await hmacSHA256(kService, 'aws4_request');
    const signatureBuffer = await hmacSHA256(kSigning, stringToSign);
    const signature = [...signatureBuffer].map(b => b.toString(16).padStart(2, '0')).join('');

    const authorizationHeader = `AWS4-HMAC-SHA256 Credential=${accessKeyId}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

    return {
        url: `https://${host}${canonicalUri}`,
        headers: {
            'Host': host,
            'x-amz-date': amzDate,
            'x-amz-content-sha256': payloadHash,
            'Authorization': authorizationHeader,
            ...extraHeaders,
        },
    };
}

// =============================================================
// R2 File Handler — Cross-Account via S3 API
// =============================================================

async function handleR2File(request, env, objectKey, mode) {
    const accountId = env.R2_ACCOUNT_ID;
    const bucketName = env.R2_BUCKET_NAME;
    const accessKeyId = env.R2_ACCESS_KEY_ID;
    const secretAccessKey = env.R2_SECRET_ACCESS_KEY;

    if (!accountId || !bucketName || !accessKeyId || !secretAccessKey) {
        return new Response('R2 cross-account credentials not configured', { status: 500 });
    }

    const rangeHeader = request.headers.get('Range');
    const fileName = objectKey.split('/').pop();

    // --- HEAD request ---
    if (request.method === 'HEAD') {
        const signed = await signR2Request('HEAD', objectKey, accountId, bucketName, accessKeyId, secretAccessKey, null);
        const r2Resp = await fetch(signed.url, { method: 'HEAD', headers: signed.headers });

        if (r2Resp.status === 404 || r2Resp.status === 403) {
            return new Response(null, { status: 404 });
        }

        const headers = new Headers();
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges');
        headers.set('Accept-Ranges', 'bytes');
        headers.set('Cache-Control', 'public, max-age=31536000');

        const contentLength = r2Resp.headers.get('Content-Length');
        if (contentLength) headers.set('Content-Length', contentLength);

        const etag = r2Resp.headers.get('ETag');
        if (etag) headers.set('ETag', etag);

        const contentType = r2Resp.headers.get('Content-Type');
        const mime = getVideoMimeType(objectKey);
        if (mime) {
            headers.set('Content-Type', mime);
        } else if (contentType) {
            headers.set('Content-Type', contentType);
        }

        if (mode === 'download') {
            headers.set('Content-Disposition', `attachment; filename="${fileName}"`);
        } else {
            headers.set('Content-Disposition', 'inline');
        }

        return new Response(null, { status: 200, headers });
    }

    // --- GET request (with optional Range) ---
    const signed = await signR2Request('GET', objectKey, accountId, bucketName, accessKeyId, secretAccessKey, rangeHeader);
    const r2Resp = await fetch(signed.url, { method: 'GET', headers: signed.headers });

    if (r2Resp.status === 404 || r2Resp.status === 403) {
        return new Response('File Not Found', { status: 404 });
    }

    const headers = new Headers();
    headers.set('Access-Control-Allow-Origin', '*');
    headers.set('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges');
    headers.set('Accept-Ranges', 'bytes');
    headers.set('Cache-Control', 'public, max-age=31536000');

    const etag = r2Resp.headers.get('ETag');
    if (etag) headers.set('ETag', etag);

    const mime = getVideoMimeType(objectKey);
    const contentType = r2Resp.headers.get('Content-Type');
    if (mime) {
        headers.set('Content-Type', mime);
    } else if (contentType) {
        headers.set('Content-Type', contentType);
    }

    if (mode === 'download') {
        headers.set('Content-Disposition', `attachment; filename="${fileName}"`);
    } else {
        headers.set('Content-Disposition', 'inline');
    }

    // Range response (206) or full response (200)
    if (rangeHeader && r2Resp.status === 206) {
        const contentRange = r2Resp.headers.get('Content-Range');
        if (contentRange) headers.set('Content-Range', contentRange);

        const contentLength = r2Resp.headers.get('Content-Length');
        if (contentLength) headers.set('Content-Length', contentLength);

        return new Response(r2Resp.body, { status: 206, headers });
    }

    const contentLength = r2Resp.headers.get('Content-Length');
    if (contentLength) headers.set('Content-Length', contentLength);

    return new Response(r2Resp.body, { status: 200, headers });
}

// --- SS Request Handler ---
async function handleSSRequest(request, customProxyIP) {
    const wssPair = new WebSocketPair();
    const [clientSock, serverSock] = Object.values(wssPair);
    serverSock.accept();
    let remoteConnWrapper = { socket: null };
    let isDnsQuery = false;
    const earlyData = request.headers.get('sec-websocket-protocol') || '';
    const readable = makeReadableStr(serverSock, earlyData);
    readable.pipeTo(new WritableStream({
        async write(chunk) {
            if (isDnsQuery) return await forwardataudp(chunk, serverSock, null);
            if (remoteConnWrapper.socket) {
                const writer = remoteConnWrapper.socket.writable.getWriter();
                await writer.write(chunk);
                writer.releaseLock();
                return;
            }
            const { hasError, message, addressType, port, hostname, rawIndex } = parseSSPacketHeader(chunk);
            if (hasError) throw new Error(message);
            if (addressType === 2) {
                if (port === 53) isDnsQuery = true;
                else throw new Error('UDP is not supported');
            }
            const rawData = chunk.slice(rawIndex);
            if (isDnsQuery) return forwardataudp(rawData, serverSock, null);
            await forwardataTCP(hostname, port, rawData, serverSock, null, remoteConnWrapper, customProxyIP);
        },
    })).catch((err) => {});
    return new Response(null, { status: 101, webSocket: clientSock });
}

function parseSSPacketHeader(chunk) {
    if (chunk.byteLength < 7) return { hasError: true, message: 'Invalid data' };
    try {
        const view = new Uint8Array(chunk);
        const addressType = view[0];
        let addrIdx = 1, addrLen = 0, addrValIdx = addrIdx, hostname = '';
        switch (addressType) {
            case 1: addrLen = 4; hostname = new Uint8Array(chunk.slice(addrValIdx, addrValIdx + addrLen)).join('.'); addrValIdx += addrLen; break;
            case 3: addrLen = view[addrIdx]; addrValIdx += 1; hostname = new TextDecoder().decode(chunk.slice(addrValIdx, addrValIdx + addrLen)); addrValIdx += addrLen; break;
            case 4: addrLen = 16; const ipv6 = []; const ipv6View = new DataView(chunk.slice(addrValIdx, addrValIdx + addrLen)); for (let i = 0; i < 8; i++) ipv6.push(ipv6View.getUint16(i * 2).toString(16)); hostname = ipv6.join(':'); addrValIdx += addrLen; break;
            default: return { hasError: true, message: `Invalid address type: ${addressType}` };
        }
        const port = new DataView(chunk.slice(addrValIdx, addrValIdx + 2)).getUint16(0);
        return { hasError: false, addressType, port, hostname, rawIndex: addrValIdx + 2 };
    } catch (e) { return { hasError: true, message: 'Failed to parse SS packet header' }; }
}

async function forwardataTCP(host, portNum, rawData, ws, respHeader, remoteConnWrapper, customProxyIP) {
    async function connectDirect(address, port, data) {
        const remoteSock = connect({ hostname: address, port: port });
        const writer = remoteSock.writable.getWriter();
        await writer.write(data);
        writer.releaseLock();
        return remoteSock;
    }
    let proxyConfig = parsePryAddress(customProxyIP || proxyIP) || { type: 'direct', host: proxyIP, port: 443 };
    async function connecttoPry() {
        let newSocket;
        if (proxyConfig.type === 'socks5') newSocket = await connect2Socks5(proxyConfig, host, portNum, rawData);
        else if (proxyConfig.type === 'http' || proxyConfig.type === 'https') newSocket = await connect2Http(proxyConfig, host, portNum, rawData);
        else newSocket = await connectDirect(proxyConfig.host, proxyConfig.port, rawData);
        remoteConnWrapper.socket = newSocket;
        newSocket.closed.catch(() => {}).finally(() => closeSocketQuietly(ws));
        connectStreams(newSocket, ws, respHeader, null);
    }
    try {
        const initialSocket = await connectDirect(host, portNum, rawData);
        remoteConnWrapper.socket = initialSocket;
        connectStreams(initialSocket, ws, respHeader, connecttoPry);
    } catch (err) { await connecttoPry(); }
}

function makeReadableStr(socket, earlyDataHeader) {
    let cancelled = false;
    return new ReadableStream({
        start(controller) {
            socket.addEventListener('message', (event) => { if (!cancelled) controller.enqueue(event.data); });
            socket.addEventListener('close', () => { if (!cancelled) { closeSocketQuietly(socket); controller.close(); } });
            socket.addEventListener('error', (err) => controller.error(err));
            const { earlyData, error } = base64ToArray(earlyDataHeader);
            if (error) controller.error(error); else if (earlyData) controller.enqueue(earlyData);
        },
        cancel() { cancelled = true; closeSocketQuietly(socket); }
    });
}

async function connectStreams(remoteSocket, webSocket, headerData, retryFunc) {
    let header = headerData, hasData = false;
    await remoteSocket.readable.pipeTo(new WritableStream({
        async write(chunk, controller) {
            hasData = true;
            if (webSocket.readyState !== WebSocket.OPEN) controller.error('wsreadyState not open');
            if (header) {
                const resp = new Uint8Array(header.length + chunk.byteLength);
                resp.set(header, 0); resp.set(chunk, header.length);
                webSocket.send(resp.buffer); header = null;
            } else webSocket.send(chunk);
        },
        abort() {},
    })).catch(() => { closeSocketQuietly(webSocket); });
    if (!hasData && retryFunc) await retryFunc();
}

async function forwardataudp(udpChunk, webSocket, respHeader) {
    try {
        const tcpSocket = connect({ hostname: '8.8.4.4', port: 53 });
        let vHeader = respHeader;
        const writer = tcpSocket.writable.getWriter();
        await writer.write(udpChunk);
        writer.releaseLock();
        await tcpSocket.readable.pipeTo(new WritableStream({
            async write(chunk) {
                if (webSocket.readyState === WebSocket.OPEN) {
                    if (vHeader) {
                        const resp = new Uint8Array(vHeader.length + chunk.byteLength);
                        resp.set(vHeader, 0); resp.set(chunk, vHeader.length);
                        webSocket.send(resp.buffer); vHeader = null;
                    } else webSocket.send(chunk);
                }
            },
        }));
    } catch (error) {}
}

function getSimplePage(request) {
    const url = request.headers.get('Host');
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Service Status</title><style>body{font-family:sans-serif;background:#f4f7f6;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}.card{background:white;padding:2rem;border-radius:12px;box-shadow:0 4px 6px rgba(0,0,0,0.1);text-align:center;}</style></head><body><div class="card"><h1>https://t.me/iqowoq</h1><p>Domain: ${url}</p></div></body></html>`;
    return new Response(html, { headers: { 'Content-Type': 'text/html;charset=utf-8' } });
}

// --- Main Fetch Handler ---
export default {
    async fetch(request, env) {
        try {
            const url = new URL(request.url);
            const pathname = url.pathname;

            // --- CORS Preflight ---
            if (request.method === 'OPTIONS') {
                return new Response(null, {
                    status: 204,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
                        'Access-Control-Allow-Headers': 'Range, Content-Type',
                        'Access-Control-Expose-Headers': 'Content-Range, Content-Length, Accept-Ranges',
                        'Access-Control-Max-Age': '86400',
                    },
                });
            }

            // --- ၁။ R2 Video Watch (browser မှာ ကြည့်ဖို့) ---
            if (pathname.startsWith('/video/')) {
                const objectKey = decodeURIComponent(pathname.replace('/video/', ''));
                return await handleR2File(request, env, objectKey, 'watch');
            }

            // --- ၂။ R2 Video Download (ဖုန်းထဲ download ဆင်းဖို့) ---
            if (pathname.startsWith('/download/')) {
                const objectKey = decodeURIComponent(pathname.replace('/download/', ''));
                return await handleR2File(request, env, objectKey, 'download');
            }

            // --- ၃။ Proxy Configuration Logic ---
            password = env.PASSWORD || env.password || env.uuid || env.UUID || password;
            subPath = env.SUB_PATH || env.subpath || subPath;
            SSpath = env.SSPATH || env.sspath || SSpath || password;
            if (subPath === 'link' || subPath === '') subPath = password;

            const validPath = `/${SSpath}`;

            if (request.headers.get('Upgrade') === 'websocket') {
                if (!pathname.toLowerCase().startsWith(validPath.toLowerCase())) {
                    return new Response('Unauthorized', { status: 401 });
                }
                const customProxyIP = url.searchParams.get('proxyip') || request.headers.get('proxyip');
                return await handleSSRequest(request, customProxyIP);
            }

            if (pathname === '/') return getSimplePage(request);

            if (pathname.toLowerCase() === `/${password.toLowerCase()}`) {
                const currentDomain = url.hostname;
                const vUrl = `https://${currentDomain}/sub/${subPath}`;
                return new Response(`Subscription Link: ${vUrl}`, { status: 200 });
            }

            if (pathname.toLowerCase() === `/sub/${subPath.toLowerCase()}`) {
                const currentDomain = url.hostname;
                const ssLinks = cfip.map(cdnItem => {
                    const [hostPart, nodeName] = cdnItem.split('#');
                    const [host, port = 443] = hostPart.split(':');
                    const encodedConfig = btoa(`none:${password}`);
                    return `ss://${encodedConfig}@${host}:${port}?plugin=v2ray-plugin;mode=websocket;host=${currentDomain};path=${validPath}/?ed=2560;tls;sni=${currentDomain}#${nodeName || 'SS'}`;
                }).join('\n');
                return new Response(btoa(ssLinks), { headers: { 'Content-Type': 'text/plain' } });
            }

            return new Response('Not Found', { status: 404 });
        } catch (err) {
            return new Response(err.message, { status: 500 });
        }
    },
};
